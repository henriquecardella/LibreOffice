# Pivot Fácil 1.2.0 — LibreOffice Calc

## Multilíngue / Multilingual / Multilingüe / Mehrsprachig / Multilingue

Idiomas incluídos: **Português (Brasil), English, Español, Deutsch, Français, Italiano**.

- Detecta automaticamente o idioma da interface do LibreOffice (inclusive 26.2.6).
- Menu e dicas na barra seguem o idioma do LibreOffice.
- No canto superior direito do assistente, selecione idioma manualmente (ou Auto).
- A escolha manual fica salva nas preferências do usuário em `~/.config/pivot-facil/settings.json` no Ubuntu.
- Mudança de idioma ocorre instantaneamente no diálogo: textos, ajuda `?`, nomes dos cálculos e mensagens.
- Os cabeçalhos e dados originais NÃO são traduzidos, para manter a integridade dos relatórios.
- Funções internas têm códigos imutáveis: Sum/Count/Average/Min/Max apenas são exibidos no idioma escolhido.
- Preserva diálogo compacto, toolbar à direita, campos arrastáveis, etiqueta no cursor e atualização das tabelas.

**Instalação:** LibreOffice Calc → Ferramentas → Gerenciador de Extensões → adicionar `.oxt`. Reiniciar o LibreOffice. Remover a versão 1.1.1 antes de instalar esta versão. Os dados da planilha são preservados.

**Compatibilidade:** API UNO/DataPilot; versão-alvo LibreOffice 26.2.6 Ubuntu. A instalação nesta versão precisa de validação no ambiente do usuário; teste de integração realizado em 25.2.3.2 Linux.

## English
The extension follows the LibreOffice user-interface language automatically. Select another language at the top-right corner of the pivot wizard; the preference persists. Menu text follows LibreOffice itself. Spreadsheet column headers are never translated. Existing pivot table data stays untouched.

## Español
La extensión detecta el idioma de la interfaz de LibreOffice. Puede cambiarlo manualmente en la esquina superior derecha del asistente. Los encabezados y los datos de las hojas no se traducen.

## Deutsch
Die Erweiterung übernimmt die LibreOffice-Oberflächensprache. Die Sprache lässt sich oben rechts im Assistenten ändern. Quelldaten und Spaltenüberschriften bleiben unverändert.

## Français
L’extension suit la langue de l’interface LibreOffice. Vous pouvez sélectionner une autre langue en haut à droite de l’assistant. Les données et les en-têtes ne sont jamais traduits.

## Italiano
L’estensione rileva la lingua dell’interfaccia di LibreOffice. Puoi scegliere un’altra lingua in alto a destra nella finestra. Le intestazioni e i dati del foglio rimangono invariati.
