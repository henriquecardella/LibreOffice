# -*- coding: utf-8 -*-
"""Pivot Facil: a native LibreOffice Calc DataPilot visual assistant.

No external dependencies. Compatible with LibreOffice's built-in Python/UNO.
"""
import re
import os
import json
from pathlib import Path
import traceback

import uno
import unohelper

from com.sun.star.task import XJobExecutor
from com.sun.star.awt import XActionListener, XMouseListener, XMouseMotionListener, XItemListener
from com.sun.star.awt.PosSize import POS, POSSIZE
from com.sun.star.datatransfer import XTransferable, DataFlavor
from com.sun.star.datatransfer.dnd import (XDragGestureListener,
                                          XDragSourceListener,
                                          XDropTargetListener)
from com.sun.star.datatransfer.dnd.DNDConstants import ACTION_COPY
from com.sun.star.sheet.DataPilotFieldOrientation import HIDDEN, ROW, COLUMN, DATA, PAGE
from com.sun.star.sheet.GeneralFunction import SUM, COUNT, AVERAGE, MIN, MAX

IMPLEMENTATION = "br.com.cardella.calc.PivotFacilJob"
SERVICE = "br.com.cardella.calc.PivotFacil"
# Stable function keys: changing the language must never change an aggregation.
FUNCTIONS = (("sum", SUM), ("count", COUNT), ("average", AVERAGE),
             ("min", MIN), ("max", MAX))
ROLES = ("rows", "columns", "values", "filters")
ORIENTATION = {"rows": ROW, "columns": COLUMN, "values": DATA, "filters": PAGE}



# Translations cover menus (Addons.xcu), dialog, messages, and contextual help.
TRANSLATIONS = {'de-DE': {'add_columns': '+ Spalte',
           'add_filters': '+ Filter',
           'add_rows': '+ Zeile',
           'add_values': '+ Wert',
           'apply': 'Anwenden',
           'available': 'FELDER',
           'cancel': 'Abbrechen',
           'columns': 'SPALTEN',
           'create': 'Erstellen',
           'default_title': 'Pivottabelle',
           'dialog_edit': 'Pivottabelle bearbeiten',
           'dialog_new': 'Neue Pivottabelle',
           'duplicate_header': 'Doppelte Überschrift: {name}. Spalte umbenennen.',
           'extension_description': 'Kompakter Assistent für native Calc-Pivottabellen mit Drag-and-drop und '
                                    'kontextbezogener Hilfe.',
           'extension_name': 'Pivot Fácil — Pivottabellen für Calc',
           'failures': 'Fehler:',
           'filters': 'FILTER',
           'fn_average': 'Mittelwert',
           'fn_count': 'Anzahl',
           'fn_max': 'Maximum',
           'fn_min': 'Minimum',
           'fn_sum': 'Summe',
           'function_label': 'Funktion:',
           'header_changed': 'Überschriften geändert. Assistent für neue Feldliste öffnen.',
           'heading': 'PIVOTTABELLE KONFIGURIEREN',
           'help_available': 'FELDER: in Zeilen, Spalten, Werte oder Filter ziehen. Jedes Feld darf nur in '
                             'einem Bereich liegen. Zum Entfernen zurück nach Felder ziehen.',
           'help_columns': 'SPALTEN: Kategorien horizontal vergleichen, etwa Produkt oder Monat.',
           'help_filters': 'FILTER: Ergebnisse einschränken, ohne die Quelldaten zu verändern.',
           'help_function': 'FUNKTION: Feld unter Werte auswählen, Operation wählen und Anwenden klicken. '
                            'Text wird normalerweise gezählt.',
           'help_rows': 'ZEILEN: Datensätze vertikal gruppieren, etwa nach Verkäufer oder Region. Die '
                        'Reihenfolge kann per Ziehen festgelegt werden.',
           'help_source': 'QUELLE: vor dem Öffnen eine Zelle im Datenbereich wählen. Zusammenhängende Daten '
                          'werden erkannt; alternativ A1:G500 eingeben. Erste Zeile: eindeutige '
                          'Überschriften.',
           'help_title': 'Hilfe — {topic}',
           'help_title_field': 'TITEL: Der Bericht wird auf einem neuen Blatt erstellt; die Quelldaten '
                               'bleiben unverändert.',
           'help_values': 'WERTE: Summe, Anzahl, Mittelwert, Minimum oder Maximum berechnen. Feld auswählen '
                          'und mit Anwenden die Funktion ändern.',
           'language_help': 'Sprache der Erweiterung. Auto verwendet die LibreOffice-Oberflächensprache.',
           'menu_config': 'Pivottabelle konfigurieren...',
           'menu_edit': 'Ausgewählte Pivottabelle bearbeiten...',
           'menu_new': 'Neue Pivottabelle...',
           'menu_refresh': 'Alle Pivottabellen aktualisieren',
           'missing_dimension': 'Mindestens ein Feld unter Zeilen oder Spalten hinzufügen.',
           'missing_header': 'Spalte {column} hat keine Überschrift. Bitte erste Zeile ergänzen.',
           'missing_value': 'Mindestens ein Feld unter Werte hinzufügen.',
           'need_calc': 'Öffnen Sie eine Calc-Tabelle, bevor Sie Pivot Fácil verwenden.',
           'need_rows': 'Die Quelle benötigt Überschriften und mindestens eine Datenzeile.',
           'pivot_source': 'Native Pivottabelle • Quelle: {name}',
           'remove': 'Entf.',
           'rows': 'ZEILEN',
           'save': 'Speichern',
           'select_field': 'Wählen Sie ein Feld unter FELDER.',
           'select_pivot': 'Klicken Sie in eine Pivottabelle, um sie zu bearbeiten.',
           'select_range': 'Wählen Sie eine Zelle oder einen Datenbereich aus.',
           'select_value': 'Wählen Sie zuerst ein Feld unter WERTE.',
           'sheet_label': 'Blatt: {name}',
           'single_sheet': 'Wählen Sie nur Daten aus einem Tabellenblatt.',
           'source_label': 'Quelle:',
           'status': '{fields} Felder | {rows} Zeilen',
           'tip': 'Felder in Bereiche ziehen oder Tasten verwenden.',
           'title_label': 'Titel:',
           'too_many_columns': 'Die Quelle enthält zu viele Spalten. Bereich verkleinern.',
           'toolbar_config': 'Pivot Fácil — Pivottabelle erstellen oder bearbeiten',
           'toolbar_refresh': 'Pivot Fácil — Alle Pivottabellen aktualisieren',
           'updated': '{count} Pivottabelle(n) aktualisiert.',
           'values': 'WERTE'},
 'en-US': {'add_columns': '+ Column',
           'add_filters': '+ Filter',
           'add_rows': '+ Row',
           'add_values': '+ Value',
           'apply': 'Apply',
           'available': 'FIELDS',
           'cancel': 'Cancel',
           'columns': 'COLUMNS',
           'create': 'Create pivot',
           'default_title': 'Pivot table',
           'dialog_edit': 'Edit pivot table',
           'dialog_new': 'New pivot table',
           'duplicate_header': 'Duplicate header: {name}. Rename the column.',
           'extension_description': 'Compact native Calc pivot table wizard with drag and drop and '
                                    'contextual help.',
           'extension_name': 'Pivot Fácil — Pivot Tables for Calc',
           'failures': 'Failed:',
           'filters': 'FILTERS',
           'fn_average': 'Average',
           'fn_count': 'Count',
           'fn_max': 'Maximum',
           'fn_min': 'Minimum',
           'fn_sum': 'Sum',
           'function_label': 'Aggregate:',
           'header_changed': 'Headers have changed. Reopen the assistant to reload fields.',
           'heading': 'CONFIGURE PIVOT TABLE',
           'help_available': 'FIELDS: drag a field into Rows, Columns, Values, or Filters. Each field '
                             'occupies one area. Drag it back to Fields to remove it.',
           'help_columns': 'COLUMNS: compare categories horizontally, e.g., Product or Month.',
           'help_filters': 'FILTERS: restrict the pivot table results without changing source data.',
           'help_function': 'AGGREGATE: select a field in Values, choose a function and click Apply. Text is '
                            'usually counted.',
           'help_rows': 'ROWS: groups records vertically, e.g., Salesperson or Region. Drag fields to set '
                        'their grouping order.',
           'help_source': 'SOURCE: select any cell in the dataset before opening the assistant. Its '
                          'contiguous region is detected, or enter A1:G500. The first row must have unique '
                          'headers.',
           'help_title': 'Help — {topic}',
           'help_title_field': 'TITLE: the report is created on a new sheet, keeping the source data intact.',
           'help_values': 'VALUES: calculate Sum, Count, Average, Minimum or Maximum. Select a field and '
                          'click Apply to change the calculation.',
           'language_help': 'Extension language. Auto follows the LibreOffice interface language.',
           'menu_config': 'Configure pivot table...',
           'menu_edit': 'Edit selected pivot table...',
           'menu_new': 'New pivot table...',
           'menu_refresh': 'Refresh all pivot tables',
           'missing_dimension': 'Add at least one field to Rows or Columns.',
           'missing_header': 'Column {column} has no header; fill in the first row.',
           'missing_value': 'Add at least one field to Values.',
           'need_calc': 'Open a Calc spreadsheet before using Pivot Fácil.',
           'need_rows': 'The source must have headers and at least one data row.',
           'pivot_source': 'Native pivot table • Source: {name}',
           'remove': 'Remove',
           'rows': 'ROWS',
           'save': 'Save',
           'select_field': 'Select a field under FIELDS.',
           'select_pivot': 'Click any cell inside a pivot table to edit it.',
           'select_range': 'Select a cell or data range in the table.',
           'select_value': 'First select a field under VALUES.',
           'sheet_label': 'Sheet: {name}',
           'single_sheet': 'Select data from one sheet only.',
           'source_label': 'Source:',
           'status': '{fields} fields | {rows} rows',
           'tip': 'Drag fields into an area, or use the buttons.',
           'title_label': 'Title:',
           'too_many_columns': 'The source has too many columns. Select a smaller range.',
           'toolbar_config': 'Pivot Fácil — Create or edit pivot table',
           'toolbar_refresh': 'Pivot Fácil — Refresh all pivot tables',
           'updated': '{count} pivot table(s) refreshed.',
           'values': 'VALUES'},
 'es-ES': {'add_columns': '+ Columna',
           'add_filters': '+ Filtro',
           'add_rows': '+ Fila',
           'add_values': '+ Valor',
           'apply': 'Aplicar',
           'available': 'CAMPOS',
           'cancel': 'Cancelar',
           'columns': 'COLUMNAS',
           'create': 'Crear tabla',
           'default_title': 'Tabla dinámica',
           'dialog_edit': 'Editar tabla dinámica',
           'dialog_new': 'Nueva tabla dinámica',
           'duplicate_header': 'Encabezado duplicado: {name}. Cambie el nombre.',
           'extension_description': 'Asistente compacto para tablas dinámicas nativas de Calc con arrastrar '
                                    'y soltar y ayuda contextual.',
           'extension_name': 'Pivot Fácil — Tablas dinámicas para Calc',
           'failures': 'Errores:',
           'filters': 'FILTROS',
           'fn_average': 'Promedio',
           'fn_count': 'Recuento',
           'fn_max': 'Máximo',
           'fn_min': 'Mínimo',
           'fn_sum': 'Suma',
           'function_label': 'Cálculo:',
           'header_changed': 'Los encabezados cambiaron. Abra de nuevo el asistente.',
           'heading': 'CONFIGURAR TABLA DINÁMICA',
           'help_available': 'CAMPOS: arrastre un campo a Filas, Columnas, Valores o Filtros. Cada campo '
                             'solo puede estar en un área. Arrástrelo de vuelta a Campos para quitarlo.',
           'help_columns': 'COLUMNAS: compara categorías horizontalmente, por ejemplo Producto o Mes.',
           'help_filters': 'FILTROS: restringe los resultados sin modificar los datos de origen.',
           'help_function': 'CÁLCULO: seleccione un campo en Valores, elija la operación y pulse Aplicar. '
                            'Para texto, use normalmente Recuento.',
           'help_rows': 'FILAS: agrupa registros verticalmente, por ejemplo Vendedor o Región. Arrastre los '
                        'campos para ordenar los grupos.',
           'help_source': 'ORIGEN: seleccione una celda de los datos antes de abrir el asistente. Se '
                          'detectará la región contigua, o introduzca A1:G500. Los encabezados deben ser '
                          'únicos.',
           'help_title': 'Ayuda — {topic}',
           'help_title_field': 'TÍTULO: el informe se crea en una hoja nueva y conserva los datos '
                               'originales.',
           'help_values': 'VALORES: realiza Suma, Recuento, Promedio, Mínimo o Máximo. Seleccione un campo y '
                          'pulse Aplicar para cambiar la función.',
           'language_help': 'Idioma de la extensión. Automático sigue el idioma de LibreOffice.',
           'menu_config': 'Configurar tabla dinámica...',
           'menu_edit': 'Editar tabla seleccionada...',
           'menu_new': 'Nueva tabla dinámica...',
           'menu_refresh': 'Actualizar todas las tablas dinámicas',
           'missing_dimension': 'Añada al menos un campo a Filas o Columnas.',
           'missing_header': 'La columna {column} no tiene encabezado; complete la primera fila.',
           'missing_value': 'Añada al menos un campo a Valores.',
           'need_calc': 'Abra una hoja de Calc antes de usar Pivot Fácil.',
           'need_rows': 'El origen necesita encabezados y al menos una fila de datos.',
           'pivot_source': 'Tabla dinámica nativa • Origen: {name}',
           'remove': 'Quitar',
           'rows': 'FILAS',
           'save': 'Guardar',
           'select_field': 'Seleccione un campo de CAMPOS.',
           'select_pivot': 'Haga clic en una celda de la tabla dinámica para editarla.',
           'select_range': 'Seleccione una celda o rango de datos de la tabla.',
           'select_value': 'Primero seleccione un campo de VALORES.',
           'sheet_label': 'Hoja: {name}',
           'single_sheet': 'Seleccione datos de una sola hoja.',
           'source_label': 'Origen:',
           'status': '{fields} campos | {rows} filas',
           'tip': 'Arrastre campos a las áreas o use los botones.',
           'title_label': 'Título:',
           'too_many_columns': 'El origen tiene demasiadas columnas. Seleccione otro rango.',
           'toolbar_config': 'Pivot Fácil — Crear o editar tabla dinámica',
           'toolbar_refresh': 'Pivot Fácil — Actualizar todas las tablas dinámicas',
           'updated': '{count} tabla(s) dinámica(s) actualizada(s).',
           'values': 'VALORES'},
 'fr-FR': {'add_columns': '+ Colonne',
           'add_filters': '+ Filtre',
           'add_rows': '+ Ligne',
           'add_values': '+ Valeur',
           'apply': 'Appliquer',
           'available': 'CHAMPS',
           'cancel': 'Annuler',
           'columns': 'COLONNES',
           'create': 'Créer tableau',
           'default_title': 'Tableau croisé',
           'dialog_edit': 'Modifier le tableau croisé',
           'dialog_new': 'Nouveau tableau croisé dynamique',
           'duplicate_header': 'En-tête en double : {name}. Renommez la colonne.',
           'extension_description': 'Assistant compact de tableaux croisés natifs avec glisser-déposer et '
                                    'aide contextuelle.',
           'extension_name': 'Pivot Fácil — Tableaux croisés pour Calc',
           'failures': 'Échecs :',
           'filters': 'FILTRES',
           'fn_average': 'Moyenne',
           'fn_count': 'Nombre',
           'fn_max': 'Maximum',
           'fn_min': 'Minimum',
           'fn_sum': 'Somme',
           'function_label': 'Calcul :',
           'header_changed': 'En-têtes modifiés. Rouvrez l’assistant pour recharger les champs.',
           'heading': 'CONFIGURER LE TABLEAU CROISÉ',
           'help_available': 'CHAMPS : glissez un champ dans Lignes, Colonnes, Valeurs ou Filtres. Chaque '
                             'champ occupe une seule zone. Ramenez-le dans Champs pour le retirer.',
           'help_columns': 'COLONNES : compare les catégories horizontalement, par exemple Produit ou Mois.',
           'help_filters': 'FILTRES : limite les résultats du tableau croisé sans modifier la source.',
           'help_function': 'CALCUL : sélectionnez un champ dans Valeurs, choisissez une fonction et cliquez '
                            'sur Appliquer. Le texte est généralement compté.',
           'help_rows': 'LIGNES : regroupe verticalement les données, par exemple par vendeur ou région. '
                        'Glissez les champs pour choisir leur ordre.',
           'help_source': 'SOURCE : sélectionnez une cellule de la base avant d’ouvrir l’assistant. La zone '
                          'contiguë est détectée, ou indiquez A1:G500. Les en-têtes doivent être uniques.',
           'help_title': 'Aide — {topic}',
           'help_title_field': 'TITRE : le rapport est créé dans une nouvelle feuille et préserve les '
                               'données de départ.',
           'help_values': 'VALEURS : Somme, Nombre, Moyenne, Minimum ou Maximum. Sélectionnez un champ et '
                          'cliquez sur Appliquer pour changer le calcul.',
           'language_help': 'Langue de l’extension. Auto suit la langue de LibreOffice.',
           'menu_config': 'Configurer le tableau croisé...',
           'menu_edit': 'Modifier le tableau sélectionné...',
           'menu_new': 'Nouveau tableau croisé...',
           'menu_refresh': 'Actualiser tous les tableaux croisés',
           'missing_dimension': 'Ajoutez un champ dans Lignes ou Colonnes.',
           'missing_header': 'La colonne {column} n’a pas d’en-tête ; complétez la première ligne.',
           'missing_value': 'Ajoutez au moins un champ dans Valeurs.',
           'need_calc': 'Ouvrez une feuille Calc avant d’utiliser Pivot Fácil.',
           'need_rows': 'La source doit contenir des en-têtes et au moins une ligne.',
           'pivot_source': 'Tableau croisé natif • Source : {name}',
           'remove': 'Retirer',
           'rows': 'LIGNES',
           'save': 'Enregistrer',
           'select_field': 'Sélectionnez un champ dans CHAMPS.',
           'select_pivot': 'Cliquez dans un tableau croisé pour le modifier.',
           'select_range': 'Sélectionnez une cellule ou une plage de données.',
           'select_value': 'Sélectionnez d’abord un champ dans VALEURS.',
           'sheet_label': 'Feuille : {name}',
           'single_sheet': 'Sélectionnez des données d’une seule feuille.',
           'source_label': 'Source :',
           'status': '{fields} champs | {rows} lignes',
           'tip': 'Glissez les champs dans les zones ou utilisez les boutons.',
           'title_label': 'Titre :',
           'too_many_columns': 'La source a trop de colonnes. Réduisez la plage.',
           'toolbar_config': 'Pivot Fácil — Créer ou modifier un tableau croisé',
           'toolbar_refresh': 'Pivot Fácil — Actualiser tous les tableaux croisés',
           'updated': '{count} tableau(x) croisé(s) actualisé(s).',
           'values': 'VALEURS'},
 'it-IT': {'add_columns': '+ Colonna',
           'add_filters': '+ Filtro',
           'add_rows': '+ Riga',
           'add_values': '+ Valore',
           'apply': 'Applica',
           'available': 'CAMPI',
           'cancel': 'Annulla',
           'columns': 'COLONNE',
           'create': 'Crea pivot',
           'default_title': 'Tabella pivot',
           'dialog_edit': 'Modifica tabella pivot',
           'dialog_new': 'Nuova tabella pivot',
           'duplicate_header': 'Intestazione duplicata: {name}. Rinomina la colonna.',
           'extension_description': 'Procedura guidata compatta per tabelle pivot native di Calc, con '
                                    'trascinamento e guida contestuale.',
           'extension_name': 'Pivot Fácil — Tabelle pivot per Calc',
           'failures': 'Errori:',
           'filters': 'FILTRI',
           'fn_average': 'Media',
           'fn_count': 'Conteggio',
           'fn_max': 'Massimo',
           'fn_min': 'Minimo',
           'fn_sum': 'Somma',
           'function_label': 'Calcolo:',
           'header_changed': 'Intestazioni modificate. Riapri la procedura per ricaricare i campi.',
           'heading': 'CONFIGURA TABELLA PIVOT',
           'help_available': 'CAMPI: trascina un campo in Righe, Colonne, Valori o Filtri. Ogni campo occupa '
                             'un’area alla volta. Trascinalo in Campi per rimuoverlo.',
           'help_columns': 'COLONNE: confronta le categorie orizzontalmente, per esempio Prodotto o Mese.',
           'help_filters': 'FILTRI: limita i risultati senza modificare i dati di origine.',
           'help_function': 'CALCOLO: seleziona un campo in Valori, scegli l’operazione e premi Applica. Il '
                            'testo normalmente usa Conteggio.',
           'help_rows': 'RIGHE: raggruppa i dati verticalmente, per esempio per venditore o regione. '
                        'Trascina i campi per stabilire l’ordine.',
           'help_source': 'ORIGINE: seleziona una cella nei dati prima di aprire la procedura. L’area '
                          'contigua viene rilevata oppure inserisci A1:G500. Le intestazioni devono essere '
                          'univoche.',
           'help_title': 'Guida — {topic}',
           'help_title_field': 'TITOLO: il riepilogo viene creato in un nuovo foglio, lasciando intatti i '
                               'dati originali.',
           'help_values': 'VALORI: calcola Somma, Conteggio, Media, Minimo o Massimo. Seleziona un campo e '
                          'premi Applica per cambiare il calcolo.',
           'language_help': 'Lingua dell’estensione. Auto segue la lingua dell’interfaccia LibreOffice.',
           'menu_config': 'Configura tabella pivot...',
           'menu_edit': 'Modifica tabella pivot selezionata...',
           'menu_new': 'Nuova tabella pivot...',
           'menu_refresh': 'Aggiorna tutte le tabelle pivot',
           'missing_dimension': 'Aggiungi almeno un campo in Righe o Colonne.',
           'missing_header': 'La colonna {column} non ha intestazione. Compila la prima riga.',
           'missing_value': 'Aggiungi almeno un campo in Valori.',
           'need_calc': 'Apri un foglio Calc prima di utilizzare Pivot Fácil.',
           'need_rows': 'L’origine deve avere intestazioni e almeno una riga di dati.',
           'pivot_source': 'Tabella pivot nativa • Origine: {name}',
           'remove': 'Rimuovi',
           'rows': 'RIGHE',
           'save': 'Salva',
           'select_field': 'Seleziona un campo in CAMPI.',
           'select_pivot': 'Fai clic su una cella della tabella pivot per modificarla.',
           'select_range': 'Seleziona una cella o un intervallo dati.',
           'select_value': 'Seleziona prima un campo in VALORI.',
           'sheet_label': 'Foglio: {name}',
           'single_sheet': 'Seleziona i dati da un solo foglio.',
           'source_label': 'Origine:',
           'status': '{fields} campi | {rows} righe',
           'tip': 'Trascina i campi nelle aree oppure usa i pulsanti.',
           'title_label': 'Titolo:',
           'too_many_columns': 'L’origine ha troppe colonne. Riduci l’intervallo.',
           'toolbar_config': 'Pivot Fácil — Crea o modifica tabella pivot',
           'toolbar_refresh': 'Pivot Fácil — Aggiorna tutte le tabelle pivot',
           'updated': '{count} tabelle pivot aggiornate.',
           'values': 'VALORI'},
 'pt-BR': {'add_columns': '+ Coluna',
           'add_filters': '+ Filtro',
           'add_rows': '+ Linha',
           'add_values': '+ Valor',
           'apply': 'Aplicar',
           'available': 'CAMPOS',
           'cancel': 'Cancelar',
           'columns': 'COLUNAS',
           'create': 'Criar tabela',
           'default_title': 'Tabela dinâmica',
           'dialog_edit': 'Editar tabela dinâmica',
           'dialog_new': 'Nova tabela dinâmica',
           'duplicate_header': 'Cabeçalhos duplicados: {name}. Renomeie a coluna.',
           'extension_description': 'Assistente compacto para tabelas dinâmicas nativas do Calc, com '
                                    'arrastar e soltar e ajuda contextual.',
           'extension_name': 'Pivot Fácil — Tabelas Dinâmicas para Calc',
           'failures': 'Falhas:',
           'filters': 'FILTROS',
           'fn_average': 'Média',
           'fn_count': 'Contagem',
           'fn_max': 'Máximo',
           'fn_min': 'Mínimo',
           'fn_sum': 'Soma',
           'function_label': 'Cálculo:',
           'header_changed': 'Cabeçalhos alterados. Reabra o assistente para reler os campos.',
           'heading': 'CONFIGURAR TABELA DINÂMICA',
           'help_available': 'CAMPOS: arraste um campo para Linhas, Colunas, Valores ou Filtros. Cada campo '
                             'ocupa uma área por vez. Para remover, arraste de volta para Campos.',
           'help_columns': 'COLUNAS: compara categorias horizontalmente, por exemplo Produto ou Mês.',
           'help_filters': 'FILTROS: permite restringir resultados na tabela dinâmica sem alterar os dados '
                           'de origem.',
           'help_function': 'CÁLCULO: selecione um campo em Valores, escolha a operação e clique Aplicar. '
                            'Para textos, geralmente use Contagem.',
           'help_rows': 'LINHAS: agrupa registros verticalmente, por exemplo Vendedor ou Região. Arraste '
                        'campos para definir a ordem.',
           'help_source': 'ORIGEM: selecione uma célula da base antes de abrir o assistente. A região '
                          'contígua é detectada ou informe A1:G500. A primeira linha deve ter cabeçalhos '
                          'únicos.',
           'help_title': 'Ajuda — {topic}',
           'help_title_field': 'TÍTULO: o relatório será criado em uma nova aba, preservando os dados '
                               'originais.',
           'help_values': 'VALORES: calcula Soma, Contagem, Média, Mínimo ou Máximo. Selecione um campo e '
                          'clique Aplicar para mudar o cálculo.',
           'language_help': 'Idioma da extensão. Automático usa o idioma da interface do LibreOffice.',
           'menu_config': 'Configurar tabela dinâmica...',
           'menu_edit': 'Editar tabela selecionada...',
           'menu_new': 'Nova tabela dinâmica...',
           'menu_refresh': 'Atualizar todas as tabelas dinâmicas',
           'missing_dimension': 'Adicione ao menos um campo em Linhas ou Colunas.',
           'missing_header': 'A coluna {column} está sem cabeçalho; preencha a primeira linha.',
           'missing_value': 'Adicione ao menos um campo em Valores.',
           'need_calc': 'Abra uma planilha do Calc antes de usar o Pivot Fácil.',
           'need_rows': 'A origem precisa ter cabeçalho e ao menos uma linha de dados.',
           'pivot_source': 'Tabela dinâmica nativa • Origem: {name}',
           'remove': 'Remover',
           'rows': 'LINHAS',
           'save': 'Salvar',
           'select_field': 'Selecione um campo em CAMPOS.',
           'select_pivot': 'Clique em qualquer célula de uma tabela dinâmica para editá-la.',
           'select_range': 'Selecione uma célula ou intervalo de dados da tabela.',
           'select_value': 'Selecione primeiro um campo em VALORES.',
           'sheet_label': 'Aba: {name}',
           'single_sheet': 'Selecione dados de uma única planilha.',
           'source_label': 'Origem:',
           'status': '{fields} campos | {rows} linhas',
           'tip': 'Arraste os campos para as áreas; ou use os botões.',
           'title_label': 'Título:',
           'too_many_columns': 'A origem contém muitas colunas. Selecione o intervalo desejado.',
           'toolbar_config': 'Pivot Fácil — Criar ou editar tabela dinâmica',
           'toolbar_refresh': 'Pivot Fácil — Atualizar todas as tabelas dinâmicas',
           'updated': '{count} tabela(s) dinâmica(s) atualizada(s).',
           'values': 'VALORES'}}

LANGUAGE_OPTIONS = (("auto", "Auto (LibreOffice)"),
                    ("pt-BR", "Português (Brasil)"), ("en-US", "English"),
                    ("es-ES", "Español"), ("de-DE", "Deutsch"),
                    ("fr-FR", "Français"), ("it-IT", "Italiano"))
_ACTIVE_LANG = "pt-BR"


def _normalize_locale(value):
    code = str(value or "").replace("_", "-").split(".")[0].split("@")[0].lower()
    if code.startswith("pt"):
        return "pt-BR"
    for prefix, result in (("en", "en-US"), ("es", "es-ES"), ("de", "de-DE"),
                           ("fr", "fr-FR"), ("it", "it-IT")):
        if code.startswith(prefix):
            return result
    return "en-US"


def _office_language(ctx):
    try:
        provider = ctx.ServiceManager.createInstanceWithContext(
            "com.sun.star.configuration.ConfigurationProvider", ctx)
        arg = uno.createUnoStruct("com.sun.star.beans.PropertyValue")
        arg.Name, arg.Value = "nodepath", "/org.openoffice.Setup/L10N"
        node = provider.createInstanceWithArguments(
            "com.sun.star.configuration.ConfigurationAccess", (arg,))
        code = node.getPropertyValue("ooLocale")
        if code:
            return _normalize_locale(code)
    except Exception:
        pass
    return _normalize_locale(os.getenv("LC_ALL") or os.getenv("LC_MESSAGES") or
                             os.getenv("LANG") or "en-US")


def _config_file():
    # Does not alter LibreOffice settings; follows XDG on Ubuntu.
    location = os.getenv("XDG_CONFIG_HOME")
    if not location:
        if os.name == "nt":
            location = os.getenv("APPDATA") or str(Path.home() / "AppData" / "Roaming")
        elif os.sys.platform == "darwin":
            location = str(Path.home() / "Library" / "Application Support")
        else:
            location = str(Path.home() / ".config")
    return Path(location) / "pivot-facil" / "settings.json"


def _saved_choice():
    try:
        data = json.loads(_config_file().read_text(encoding="utf-8"))
        choice = data.get("language", "auto")
        return choice if choice in dict(LANGUAGE_OPTIONS) else "auto"
    except (OSError, ValueError, TypeError):
        return "auto"


def _save_choice(choice):
    try:
        path = _config_file()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps({"language": choice}, ensure_ascii=False),
                        encoding="utf-8")
    except OSError:
        # A read-only home directory must not stop pivot operations.
        pass


def _effective_lang(ctx, choice=None):
    requested = _saved_choice() if choice is None else choice
    return requested if requested in TRANSLATIONS else _office_language(ctx)


def _set_language(code):
    global _ACTIVE_LANG
    _ACTIVE_LANG = code if code in TRANSLATIONS else "pt-BR"


def tr(key, **kw):
    val = TRANSLATIONS.get(_ACTIVE_LANG, TRANSLATIONS["pt-BR"]).get(
        key, TRANSLATIONS["pt-BR"].get(key, key))
    return val.format(**kw) if kw else val


def _function_label(code):
    return tr("fn_" + code)


def _message(ctx, parent, title, content, error=False):
    try:
        toolkit = ctx.ServiceManager.createInstanceWithContext("com.sun.star.awt.Toolkit", ctx)
        from com.sun.star.awt.MessageBoxType import INFOBOX, ERRORBOX
        from com.sun.star.awt.MessageBoxButtons import BUTTONS_OK
        box = toolkit.createMessageBox(parent, ERRORBOX if error else INFOBOX,
                                       BUTTONS_OK, title, content)
        box.execute()
    except Exception:
        print("%s: %s" % (title, content))


def _calc_document(ctx):
    desktop = ctx.ServiceManager.createInstanceWithContext("com.sun.star.frame.Desktop", ctx)
    doc = desktop.getCurrentComponent()
    if doc is None or not doc.supportsService("com.sun.star.sheet.SpreadsheetDocument"):
        raise ValueError(tr("need_calc"))
    return doc


def _col_letters(index):
    letters = ""
    while True:
        index, rem = divmod(index, 26)
        letters = chr(65 + rem) + letters
        if index == 0:
            return letters
        index -= 1


def _name_for_address(sheet, address):
    start = "%s%d" % (_col_letters(address.StartColumn), address.StartRow + 1)
    end = "%s%d" % (_col_letters(address.EndColumn), address.EndRow + 1)
    return start if start == end else "%s:%s" % (start, end)


def _source_from_selection(doc):
    controller = doc.CurrentController
    sheet = controller.ActiveSheet
    selection = controller.Selection
    if not hasattr(selection, "getRangeAddress"):
        raise ValueError(tr("select_range"))
    addr = selection.getRangeAddress()
    if addr.Sheet != sheet.getCellRangeByPosition(0, 0, 0, 0).RangeAddress.Sheet:
        raise ValueError(tr("single_sheet"))
    if addr.StartRow == addr.EndRow and addr.StartColumn == addr.EndColumn:
        cursor = sheet.createCursorByRange(sheet.getCellByPosition(addr.StartColumn, addr.StartRow))
        cursor.collapseToCurrentRegion()
        addr = cursor.RangeAddress
    if addr.EndRow <= addr.StartRow:
        raise ValueError(tr("need_rows"))
    if addr.EndColumn - addr.StartColumn > 200:
        raise ValueError(tr("too_many_columns"))
    return sheet, addr


def _header_fields(sheet, addr):
    result = []
    for col in range(addr.StartColumn, addr.EndColumn + 1):
        name = sheet.getCellByPosition(col, addr.StartRow).String.strip()
        if not name:
            raise ValueError(tr("missing_header", column=col + 1))
        if name in result:
            raise ValueError(tr("duplicate_header", name=name))
        result.append(name)
    return result


def _existing_at_cursor(doc):
    try:
        selection = doc.CurrentController.Selection
        selected_addr = selection.getRangeAddress()
        for sheet_idx in range(doc.Sheets.Count):
            sheet = doc.Sheets.getByIndex(sheet_idx)
            tables = sheet.getDataPilotTables()
            for name in tables.ElementNames:
                table = tables.getByName(name)
                a = table.getOutputRange()
                if (selected_addr.Sheet == a.Sheet and
                    selected_addr.StartColumn <= a.EndColumn and selected_addr.EndColumn >= a.StartColumn and
                    selected_addr.StartRow <= a.EndRow and selected_addr.EndRow >= a.StartRow):
                    return sheet, name, table
    except Exception:
        pass
    return None


def _refresh_all(doc):
    n = 0
    errors = []
    for i in range(doc.Sheets.Count):
        sh = doc.Sheets.getByIndex(i)
        tb = sh.getDataPilotTables()
        for nm in tb.ElementNames:
            try:
                tb.getByName(nm).refresh()
                n += 1
            except Exception as exc:
                errors.append("%s / %s: %s" % (sh.Name, nm, exc))
    return n, errors


def _unique_sheet_name(doc, base):
    base = re.sub(r"[^\w ]", "_", base, flags=re.UNICODE).strip()[:22] or tr("default_title")
    name = "TD_" + base
    i = 2
    while doc.Sheets.hasByName(name):
        name = ("TD_" + base[:22] + "_%d" % i)[:31]
        i += 1
    return name


def _numeric_field(sheet, addr, index):
    col = addr.StartColumn + index
    for row in range(addr.StartRow + 1, min(addr.EndRow + 1, addr.StartRow + 35)):
        cell = sheet.getCellByPosition(col, row)
        if cell.Type.value == "VALUE":
            return True
    return False


def _read_arrangements(table, names):
    result = {r: [] for r in ROLES}
    funcs = {}
    fields = table.getDataPilotFields()
    for i, name in enumerate(names):
        field = fields.getByIndex(i)
        orient = field.Orientation
        for role, value in ORIENTATION.items():
            if orient == value:
                result[role].append(name)
                if role == "values":
                    funcs[name] = next((key for key, fn in FUNCTIONS if fn == field.Function), "sum")
                break
    return result, funcs


def _apply_layout(descriptor, names, placements, funcs):
    fields = descriptor.getDataPilotFields()
    for i, name in enumerate(names):
        fld = fields.getByIndex(i)
        fld.Orientation = HIDDEN
    for role in ROLES:
        for name in placements[role]:
            fld = fields.getByIndex(names.index(name))
            fld.Orientation = ORIENTATION[role]
            if role == "values":
                label = funcs.get(name, "sum")
                fld.Function = dict(FUNCTIONS)[label]


def _build_pivot(doc, src_sheet, source_address, names, placements, funcs, title):
    if not placements["values"]:
        raise ValueError(tr("missing_value"))
    if not (placements["rows"] or placements["columns"]):
        raise ValueError(tr("missing_dimension"))
    out_name = _unique_sheet_name(doc, title)
    doc.Sheets.insertNewByName(out_name, doc.Sheets.Count)
    out_sheet = doc.Sheets.getByName(out_name)
    try:
        tables = out_sheet.getDataPilotTables()
        descriptor = tables.createDataPilotDescriptor()
        descriptor.setSourceRange(source_address)
        _apply_layout(descriptor, names, placements, funcs)
        descriptor.ShowFilterButton = bool(placements["filters"])
        dest = out_sheet.getCellByPosition(0, 2).CellAddress
        tables.insertNewByName("PivotFacil", dest, descriptor)
        out_sheet.getCellByPosition(0, 0).String = title or tr("default_title")
        out_sheet.getCellByPosition(0, 0).CharWeight = 150
        out_sheet.getCellByPosition(0, 0).CharHeight = 15
        out_sheet.getCellByPosition(0, 1).String = tr("pivot_source", name=src_sheet.Name)
        out_sheet.Columns.getByIndex(0).Width = 4200
        doc.CurrentController.setActiveSheet(out_sheet)
        doc.CurrentController.select(out_sheet.getCellByPosition(0, 2))
    except Exception:
        doc.Sheets.removeByName(out_name)
        raise
    return out_name


def _modify_pivot(table, names, placements, funcs):
    if not placements["values"]:
        raise ValueError(tr("missing_value"))
    if not (placements["rows"] or placements["columns"]):
        raise ValueError(tr("missing_dimension"))
    before, before_funcs = _read_arrangements(table, names)
    try:
        _apply_layout(table, names, placements, funcs)
        table.refresh()
    except Exception:
        try:
            _apply_layout(table, names, before, before_funcs)
            table.refresh()
        except Exception:
            pass
        raise


class _Action(unohelper.Base, XActionListener):
    def __init__(self, callback):
        self.callback = callback

    def actionPerformed(self, event):
        try:
            self.callback(event.ActionCommand)
        except Exception:
            traceback.print_exc()

    def disposing(self, event):
        pass


class _FieldTransfer(unohelper.Base, XTransferable):
    """Payload de texto, interpretado apenas enquanto houver arraste interno ativo."""
    def __init__(self, name):
        self.name = name
        self.flavor = DataFlavor(
            "text/plain;charset=utf-16", "Campo do Pivot Fácil",
            uno.getTypeByName("string"))

    def getTransferDataFlavors(self):
        return (self.flavor,)

    def isDataFlavorSupported(self, flavor):
        return flavor.MimeType.lower() == self.flavor.MimeType.lower()

    def getTransferData(self, flavor):
        if not self.isDataFlavorSupported(flavor):
            from com.sun.star.datatransfer import UnsupportedFlavorException
            raise UnsupportedFlavorException()
        return self.name


class _DragSourceEvents(unohelper.Base, XDragSourceListener):
    def __init__(self, owner):
        self.owner = owner

    def dragDropEnd(self, event):
        self.owner._hide_drag_label()
        self.owner.dragged = None

    def dragEnter(self, event):
        pass

    def dragOver(self, event):
        pass

    def dropActionChanged(self, event):
        pass

    def dragExit(self, event):
        pass

    def disposing(self, event):
        self.owner._hide_drag_label()
        self.owner.dragged = None


class _DragStart(unohelper.Base, XDragGestureListener):
    def __init__(self, owner, role):
        self.owner = owner
        self.role = role

    def dragGestureRecognized(self, event):
        try:
            name = self.owner._drag_selection(self.role)
            if not name:
                return
            self.owner.dragged = (self.role, name)
            # event.DragSource e o XDragSource são fornecidos pelo sistema UNO.
            event.DragSource.startDrag(event, ACTION_COPY, 0, 0,
                                       _FieldTransfer(name), self.owner.drag_listener)
        except Exception:
            self.owner._hide_drag_label()
            self.owner.dragged = None
            traceback.print_exc()

    def disposing(self, event):
        pass


class _DropFields(unohelper.Base, XDropTargetListener):
    def __init__(self, owner, destination):
        self.owner = owner
        self.destination = destination

    def _acceptable(self):
        return (self.owner.dragged is not None and
                self.owner.dragged[1] in self.owner.names)

    def dragEnter(self, event):
        if self._acceptable():
            event.Context.acceptDrag(ACTION_COPY)
        else:
            event.Context.rejectDrag()

    def dragOver(self, event):
        if self._acceptable():
            event.Context.acceptDrag(ACTION_COPY)
        else:
            event.Context.rejectDrag()

    def dropActionChanged(self, event):
        self.dragOver(event)

    def dragExit(self, event):
        pass

    def drop(self, event):
        successful = False
        try:
            if self._acceptable():
                src_role, name = self.owner.dragged
                # O texto é transportado pelo UNO, mas só aceitamos campos locais.
                # source/destination são controlados pelo próprio assistente.
                successful = self.owner._move_field(name, self.destination, src_role)
        except Exception:
            traceback.print_exc()
        finally:
            event.Context.dropComplete(bool(successful))
            self.owner._hide_drag_label()
            self.owner.dragged = None

    def disposing(self, event):
        pass


class _MouseDrag(unohelper.Base, XMouseListener, XMouseMotionListener):
    """Captura do mouse: alternativa à API DND em ListBox nativo.

    No Calc/GTK o ListBox captura o mouse durante o arraste, de modo que
    mouseReleased chega à origem com coordenadas relativas mesmo após
    cruzar outras listas. Os X/Y podem ultrapassar Width/Height.
    """
    def __init__(self, owner, role):
        self.owner = owner
        self.role = role
        self.pressed = False
        self.moved = False
        self.start = (0, 0)
        self.field = None

    def mousePressed(self, event):
        if event.Buttons & 1:
            self.pressed = True
            self.moved = False
            self.start = (event.X, event.Y)
            self.field = self.owner._drag_selection(self.role)

    def mouseDragged(self, event):
        if not self.pressed or not self.field:
            return
        if not self.moved and (abs(event.X - self.start[0]) > 6 or
                               abs(event.Y - self.start[1]) > 6):
            self.moved = True
        if self.moved:
            # O campo continua legível enquanto acompanha o ponteiro.
            self.owner._show_drag_label(self.role, self.field, event.X, event.Y)

    def mouseReleased(self, event):
        try:
            if self.pressed and self.moved and self.field:
                self.owner._mouse_drop(self.role, self.field, event.X, event.Y)
        except Exception:
            traceback.print_exc()
        finally:
            self.owner._hide_drag_label()
            self.pressed = self.moved = False
            self.field = None

    def mouseMoved(self, event):
        pass

    def mouseEntered(self, event):
        pass

    def mouseExited(self, event):
        pass

    def disposing(self, event):
        self.owner._hide_drag_label()
        self.pressed = self.moved = False


class _LanguageChange(unohelper.Base, XItemListener):
    def __init__(self, owner):
        self.owner = owner

    def itemStateChanged(self, event):
        try:
            positions = self.owner.dialog.getControl("language").getSelectedItemsPos()
            if positions:
                self.owner._change_language(positions[0])
        except Exception:
            traceback.print_exc()

    def disposing(self, event):
        pass


class PivotDialog:
    """Diálogo compacto, com caixas de campos arrastáveis (DND UNO)."""

    @staticmethod
    def help_text(topic):
        key = "help_title_field" if topic == "title" else "help_" + topic
        return tr(key)

    def __init__(self, ctx, doc, edit=None):
        self.ctx, self.doc, self.edit = ctx, doc, edit
        self.language_choice = _saved_choice()
        _set_language(_effective_lang(ctx, self.language_choice))
        self.controller = doc.CurrentController
        self.parent = self.controller.Frame.ContainerWindow
        if edit:
            self.dest_sheet, self.pivot_name, self.pivot = edit
            self.addr = self.pivot.getSourceRange()
            self.src_sheet = doc.Sheets.getByIndex(self.addr.Sheet)
        else:
            self.src_sheet, self.addr = _source_from_selection(doc)
            self.pivot = None
        self.names = _header_fields(self.src_sheet, self.addr)
        self.placements = {r: [] for r in ROLES}
        self.funcs = {}
        if edit:
            self.placements, self.funcs = _read_arrangements(self.pivot, self.names)
        elif len(self.names) > 1:
            self.placements["rows"] = [self.names[0]]
            idx = next((i for i in range(1, len(self.names))
                        if _numeric_field(self.src_sheet, self.addr, i)), 1)
            name = self.names[idx]
            self.placements["values"] = [name]
            self.funcs[name] = "sum" if _numeric_field(self.src_sheet, self.addr, idx) else "count"
        self.listeners = []
        self.dnd_handles = []
        self.dragged = None
        self.drag_label_visible = False
        self.drag_label_field = None
        self.drag_listener = _DragSourceEvents(self)
        self.listeners.append(self.drag_listener)
        self._setup()

    def _control(self, name, service, x, y, w, h, **props):
        model = self.model.createInstance(service)
        model.Name = name
        model.PositionX, model.PositionY = x, y
        model.Width, model.Height = w, h
        for key, value in props.items():
            setattr(model, key, value)
        self.model.insertByName(name, model)
        return model

    def _label(self, name, text, x, y, w, h=15, **opts):
        return self._control(name, "com.sun.star.awt.UnoControlFixedTextModel",
                             x, y, w, h, Label=text, **opts)

    def _button(self, name, caption, x, y, w, h, command, helptext=""):
        m = self._control(name, "com.sun.star.awt.UnoControlButtonModel",
                          x, y, w, h, Label=caption, HelpText=helptext)
        ctrl = self.dialog.getControl(name)
        listener = _Action(self._action)
        ctrl.addActionListener(listener)
        ctrl.setActionCommand(command)
        self.listeners.append(listener)
        return m

    def _help(self, topic, x, y):
        self._button("help_" + topic, "?", x, y, 19, 17,
                     "help:" + topic, self.help_text(topic))

    def _list(self, name, x, y, w, h):
        return self._control(name, "com.sun.star.awt.UnoControlListBoxModel",
                             x, y, w, h, Dropdown=False, MultiSelection=False,
                             Border=1, HelpText=self.help_text(name))

    def _setup(self):
        self.model = self.ctx.ServiceManager.createInstanceWithContext(
            "com.sun.star.awt.UnoControlDialogModel", self.ctx)
        self.model.Width, self.model.Height = 490, 305
        self.model.Title = "Pivot Fácil | " + tr("dialog_edit" if self.edit else "dialog_new")
        self.model.Closeable, self.model.Moveable = True, True
        self._label("heading", tr("heading"), 12, 8, 315, 17,
                    FontHeight=11, FontWeight=150)
        # The language switcher updates labels, function names and help live.
        self._control("language", "com.sun.star.awt.UnoControlListBoxModel",
                      356, 6, 123, 20, Dropdown=True, Border=1,
                      HelpText=tr("language_help"),
                      StringItemList=tuple(label for key, label in LANGUAGE_OPTIONS))
        self._label("sourceLabel", tr("source_label"), 12, 34, 47)
        self._control("source", "com.sun.star.awt.UnoControlEditModel",
                      61, 31, 148, 20, Text=_name_for_address(self.src_sheet, self.addr),
                      Border=1, ReadOnly=bool(self.edit), HelpText=self.help_text("source"))
        self._label("sheetLabel", tr("sheet_label", name=self.src_sheet.Name[:30]), 241, 34, 237)
        self._label("tip", tr("tip"), 12, 59, 465)
        self._label("availableLabel", tr("available"), 12, 82, 103, 16, FontWeight=150)
        self._list("available", 12, 102, 141, 135)
        positions = {"rows": (175, 102), "columns": (333, 102),
                     "values": (175, 181), "filters": (333, 181)}
        for role in ROLES:
            x, y = positions[role]
            self._label(role + "Label", tr(role), x, y-20, 105, 16,
                        FontWeight=150)
            self._list(role, x, y, 143, 54)
        self._label("fnLabel", tr("function_label"), 261, 249, 50)
        self._control("function", "com.sun.star.awt.UnoControlListBoxModel",
                      310, 245, 86, 20, Dropdown=True, Border=1,
                      HelpText=self.help_text("function"),
                      StringItemList=tuple(_function_label(k) for k, v in FUNCTIONS))
        self._label("nameLabel", tr("title_label"), 12, 276, 42)
        self._control("name", "com.sun.star.awt.UnoControlEditModel", 54, 271, 116, 21,
                      Text=(tr("default_title") if not self.edit else self.pivot_name),
                      Border=1, ReadOnly=bool(self.edit), HelpText=self.help_text("title"))
        self._label("status", "", 191, 280, 112)

        self.dialog = self.ctx.ServiceManager.createInstanceWithContext(
            "com.sun.star.awt.UnoControlDialog", self.ctx)
        self.dialog.setModel(self.model)
        toolkit = self.ctx.ServiceManager.createInstanceWithContext(
            "com.sun.star.awt.Toolkit", self.ctx)
        self.dialog.createPeer(toolkit, self.parent)
        self._help("source", 213, 33)
        self._help("available", 134, 81)
        for role in ROLES:
            x, y = positions[role]
            self._help(role, x + 124, y - 21)
        self._help("function", 398, 248)
        self._help("title", 172, 273)

        # Button alternative to DND, keeping keyboard and touch access.
        for key, role, x, width in (("add_rows", "rows", 12, 42),
                                    ("add_columns", "columns", 55, 49),
                                    ("add_values", "values", 105, 42),
                                    ("add_filters", "filters", 148, 45)):
            self._button("add_" + role, tr(key), x, 245, width, 20,
                         "add:" + role, self.help_text(role))
        self._button("remove", tr("remove"), 195, 245, 61, 20, "remove")
        self._button("setFn", tr("apply"), 420, 245, 61, 21, "function")
        self._button("cancel", tr("cancel"), 309, 273, 81, 24, "cancel")
        self._button("save", tr("save" if self.edit else "create"), 395, 273, 86, 24, "save")

        # Inserido por último para ficar visualmente à frente das listas.
        # É um badge temporário, NÃO interfere nos dados da tabela dinâmica.
        self._label("dragLabel", "", 0, 0, 100, 14,
                    Border=1, BackgroundColor=0xE8F2FF,
                    TextColor=0x123B61, FontHeight=10, FontWeight=150)
        self.drag_label = self.dialog.getControl("dragLabel")
        self.drag_label.setVisible(False)
        self.dialog.getControl("language").selectItemPos(
            next(i for i, (code, _) in enumerate(LANGUAGE_OPTIONS)
                 if code == self.language_choice), True)
        listener = _LanguageChange(self)
        self.dialog.getControl("language").addItemListener(listener)
        self.listeners.append(listener)
        self._refresh_lists()
        self._setup_mouse_drag()
        self._setup_drag_drop(toolkit)

    def _change_language(self, selection):
        if selection < 0 or selection >= len(LANGUAGE_OPTIONS):
            return
        new_choice = LANGUAGE_OPTIONS[selection][0]
        previous_default = tr("default_title")
        self.language_choice = new_choice
        _save_choice(new_choice)
        _set_language(_effective_lang(self.ctx, new_choice))
        self.model.Title = "Pivot Fácil | " + tr("dialog_edit" if self.edit else "dialog_new")
        for name, label in (("heading", "heading"), ("sourceLabel", "source_label"),
                            ("tip", "tip"), ("availableLabel", "available"),
                            ("fnLabel", "function_label"), ("nameLabel", "title_label"),
                            ("remove", "remove"), ("setFn", "apply"),
                            ("cancel", "cancel"),
                            ("save", "save" if self.edit else "create")):
            self.dialog.getControl(name).Model.Label = tr(label)
        self.dialog.getControl("sheetLabel").Model.Label = tr(
            "sheet_label", name=self.src_sheet.Name[:30])
        for role in ROLES:
            self.dialog.getControl(role + "Label").Model.Label = tr(role)
            self.dialog.getControl("add_" + role).Model.Label = tr("add_" + role)
            self.dialog.getControl("add_" + role).Model.HelpText = self.help_text(role)
        for topic in ("source", "available") + ROLES + ("function", "title"):
            self.dialog.getControl("help_" + topic).Model.HelpText = self.help_text(topic)
        for control in ("available",) + ROLES + ("source", "function", "name"):
            topic = "title" if control == "name" else control
            self.dialog.getControl(control).Model.HelpText = self.help_text(topic)
        self.dialog.getControl("language").Model.HelpText = tr("language_help")
        self.dialog.getControl("function").Model.StringItemList = tuple(
            _function_label(key) for key, _ in FUNCTIONS)
        if not self.edit and self.dialog.getControl("name").Text == previous_default:
            self.dialog.getControl("name").Text = tr("default_title")
        self._refresh_lists()

    def _show_drag_label(self, role, field, x, y):
        """Etiqueta flutuante que acompanha o mouse durante o arraste.

        O XMouseMotionListener fornece coordenadas em pixels relativas à lista
        de origem, mesmo depois que o ponteiro sai dela (captura GTK/X11).
        Usa XWindow.setPosSize em pixels para evitar diferenças de escala
        entre as unidades do modelo do diálogo e o monitor (HiDPI).
        """
        if not field or field not in self.names:
            return
        try:
            origin = self.dialog.getControl(role).getPosSize()
            bounds = self.dialog.getPosSize()
            badge = self.drag_label.getPosSize()
            # Ajusta a largura em pixels ao nome: sem a faixa grande vazia.
            if field != self.drag_label_field:
                self.drag_label.Model.Label = "  ⇢  " + field
                self.drag_label.Model.HelpText = field
                self.drag_label_field = field
                width = min(int(bounds.Width * 0.72), max(88, 39 + len(field) * 9))
                self.drag_label.setPosSize(badge.X, badge.Y, width, 31, POSSIZE)
                badge = self.drag_label.getPosSize()
            abs_x = origin.X + x + 14
            abs_y = origin.Y + y + 13
            # Reposiciona à esquerda/acima do mouse se estiver perto da borda.
            if abs_x + badge.Width + 6 > bounds.Width:
                abs_x = origin.X + x - badge.Width - 14
            if abs_y + badge.Height + 5 > bounds.Height:
                abs_y = origin.Y + y - badge.Height - 12
            abs_x = max(2, min(abs_x, max(2, bounds.Width - badge.Width - 2)))
            abs_y = max(2, min(abs_y, max(2, bounds.Height - badge.Height - 2)))
            self.drag_label.setPosSize(int(abs_x), int(abs_y), 0, 0, POS)
            if not self.drag_label_visible:
                self.drag_label.setVisible(True)
                self.drag_label_visible = True
        except Exception:
            # A interface continua funcionando mesmo se o sistema não
            # permitir a etiqueta móvel em alguma configuração gráfica.
            traceback.print_exc()

    def _hide_drag_label(self):
        try:
            if self.drag_label_visible:
                self.drag_label.setVisible(False)
        except Exception:
            pass
        self.drag_label_visible = False
        self.drag_label_field = None

    def _setup_mouse_drag(self):
        for role in ("available",) + ROLES:
            ctl = self.dialog.getControl(role)
            listener = _MouseDrag(self, role)
            ctl.addMouseListener(listener)
            ctl.addMouseMotionListener(listener)
            self.listeners.append(listener)

    def _mouse_drop(self, source, field, x, y):
        if field not in self.names:
            return
        origin = self.dialog.getControl(source).getPosSize()
        absolute_x = origin.X + x
        absolute_y = origin.Y + y
        for target in ("available",) + ROLES:
            area = self.dialog.getControl(target).getPosSize()
            if (area.X <= absolute_x < area.X + area.Width and
                    area.Y <= absolute_y < area.Y + area.Height):
                self._move_field(field, target, source)
                return

    def _setup_drag_drop(self, toolkit):
        """Registra drag source/target nativos para todas as cinco caixas de campos."""
        try:
            for role in ("available",) + ROLES:
                window = self.dialog.getControl(role).getPeer()
                recognizer = toolkit.getDragGestureRecognizer(window)
                target = toolkit.getDropTarget(window)
                if not recognizer or not target:
                    raise RuntimeError("Arrastar e soltar indisponível nesta configuração do Calc")
                start = _DragStart(self, role)
                drop = _DropFields(self, role)
                recognizer.addDragGestureListener(start)
                target.addDropTargetListener(drop)
                target.setActive(True)
                target.setDefaultActions(ACTION_COPY)
                self.listeners.extend((start, drop))
                self.dnd_handles.append((recognizer, start, target, drop))
        except Exception as exc:
            # A captura direta do mouse já está instalada e segue operante.
            # O protocolo DND da plataforma é uma otimização opcional.
            traceback.print_exc()

    def _drag_selection(self, role):
        ctrl = self.dialog.getControl(role)
        pos = ctrl.getSelectedItemsPos()
        if not pos:
            return None
        idx = pos[0]
        fields = self.names if role == "available" else self.placements[role]
        return fields[idx] if 0 <= idx < len(fields) else None

    def _move_field(self, name, destination, source=None):
        """Move/remove campo; não permite duplicidade; conserva a ordem nas áreas."""
        if name not in self.names:
            return False
        if destination == "available":
            for role in ROLES:
                if name in self.placements[role]:
                    self.placements[role].remove(name)
            self._refresh_lists()
            return True
        if destination not in ROLES:
            return False
        # Mantém a ordem se o item já pertence à área de destino.
        if name in self.placements[destination]:
            return True
        for role in ROLES:
            if name in self.placements[role]:
                self.placements[role].remove(name)
        self.placements[destination].append(name)
        if destination == "values" and name not in self.funcs:
            index = self.names.index(name)
            self.funcs[name] = "sum" if _numeric_field(self.src_sheet, self.addr, index) else "count"
        self._refresh_lists()
        return True

    def _refresh_lists(self):
        available = self.dialog.getControl("available")
        available.removeItems(0, available.ItemCount)
        available.addItems(tuple(self.names), 0)
        if self.names:
            available.selectItemPos(0, True)
        for role in ROLES:
            ctrl = self.dialog.getControl(role)
            ctrl.removeItems(0, ctrl.ItemCount)
            items = [field + (" (" + _function_label(self.funcs.get(field, "sum")) + ")"
                              if role == "values" else "")
                     for field in self.placements[role]]
            if items:
                ctrl.addItems(tuple(items), 0)
        self.dialog.getControl("function").selectItemPos(0, True)
        self.dialog.getControl("status").Model.Label = (
            tr("status", fields=len(self.names), rows=self.addr.EndRow - self.addr.StartRow))

    def _selected_field(self):
        name = self._drag_selection("available")
        if not name:
            raise ValueError(tr("select_field"))
        return name

    def _action(self, command):
        try:
            if command == "cancel":
                self.dialog.endExecute()
                return
            if command.startswith("help:"):
                topic = command.split(":", 1)[1]
                _message(self.ctx, self.parent, tr("help_title", topic=tr({"source": "source_label", "function": "function_label", "title": "title_label"}.get(topic, topic))), self.help_text(topic))
                return
            if command.startswith("add:"):
                self._move_field(self._selected_field(), command.split(":", 1)[1])
                return
            if command == "remove":
                for role in ROLES:
                    name = self._drag_selection(role)
                    if name:
                        self._move_field(name, "available", role)
                        return
                self._move_field(self._selected_field(), "available")
                return
            if command == "function":
                selected = self.dialog.getControl("values").getSelectedItemsPos()
                if not selected:
                    raise ValueError(tr("select_value"))
                field = self.placements["values"][selected[0]]
                selected_fn = self.dialog.getControl("function").getSelectedItemsPos()
                if selected_fn:
                    self.funcs[field] = FUNCTIONS[selected_fn[0]][0]
                self._refresh_lists()
                return
            if command == "save":
                if self.edit:
                    _modify_pivot(self.pivot, self.names, self.placements, self.funcs)
                else:
                    entered = self.dialog.getControl("source").Text.strip().replace("$", "")
                    source_range = self.src_sheet.getCellRangeByName(entered)
                    addr = source_range.RangeAddress
                    if _header_fields(self.src_sheet, addr) != self.names:
                        raise ValueError(tr("header_changed"))
                    title = self.dialog.getControl("name").Text.strip() or tr("default_title")
                    _build_pivot(self.doc, self.src_sheet, addr, self.names,
                                 self.placements, self.funcs, title)
                self.dialog.endExecute()
        except Exception as exc:
            _message(self.ctx, self.parent, "Pivot Fácil", str(exc), True)

    def execute(self):
        try:
            self.dialog.execute()
        finally:
            self._hide_drag_label()
            for recognizer, start, target, drop in self.dnd_handles:
                try:
                    recognizer.removeDragGestureListener(start)
                    target.removeDropTargetListener(drop)
                except Exception:
                    pass
            self.listeners.clear()
            self.dialog.dispose()


class PivotFacilJob(unohelper.Base, XJobExecutor):
    def __init__(self, ctx):
        self.ctx = ctx

    def trigger(self, arg):
        try:
            _set_language(_effective_lang(self.ctx))
            doc = _calc_document(self.ctx)
            parent = doc.CurrentController.Frame.ContainerWindow
            key = str(arg or "").lower().strip().lstrip("?")
            if key in ("refresh", "atualizar", "refreshall"):
                n, errors = _refresh_all(doc)
                detail = tr("updated", count=n)
                if errors:
                    detail += "\n" + tr("failures") + "\n" + "\n".join(errors[:5])
                _message(self.ctx, parent, "Pivot Fácil", detail, bool(errors))
                return
            if key in ("edit", "editar"):
                existing = _existing_at_cursor(doc)
                if not existing:
                    _message(self.ctx, parent, "Pivot Fácil", tr("select_pivot"))
                    return
                PivotDialog(self.ctx, doc, existing).execute()
                return
            if key in ("configure", "configurar", "open"):
                existing = _existing_at_cursor(doc)
                PivotDialog(self.ctx, doc, existing).execute()
                return
            PivotDialog(self.ctx, doc).execute()
        except Exception as exc:
            traceback.print_exc()
            _message(self.ctx, None, "Pivot Fácil", str(exc), True)


g_ImplementationHelper = unohelper.ImplementationHelper()
g_ImplementationHelper.addImplementation(PivotFacilJob, IMPLEMENTATION,
                                         (SERVICE, "com.sun.star.task.Job"))


# Entrypoints do Calc: o framework UNO pode enviar um evento ao acionar menu/barra,
# mas nao envia argumentos em todas as outras formas de execucao.
# Aceitar *_event_args mantem ambas as modalidades compativeis.
def configurar(*_event_args):
    PivotFacilJob(XSCRIPTCONTEXT.getComponentContext()).trigger("configure")

def nova_tabela(*_event_args):
    PivotFacilJob(XSCRIPTCONTEXT.getComponentContext()).trigger("new")

def editar_tabela(*_event_args):
    PivotFacilJob(XSCRIPTCONTEXT.getComponentContext()).trigger("edit")

def atualizar_todas(*_event_args):
    PivotFacilJob(XSCRIPTCONTEXT.getComponentContext()).trigger("refresh")

g_exportedScripts = (configurar, nova_tabela, editar_tabela, atualizar_todas)
